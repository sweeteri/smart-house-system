#include "loginwindow.h"
#include "networkmanager.h"
#include <QApplication>


int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    NetworkManager &networkManager = NetworkManager::instance();
    if (networkManager.connectToServer("127.0.0.1", 1234)) {
        qDebug() << "Connected to server!";
    } else {
        qWarning() << "Failed to connect to server.";
    }
    LoginWindow w;
    w.show();

    return a.exec();
}
