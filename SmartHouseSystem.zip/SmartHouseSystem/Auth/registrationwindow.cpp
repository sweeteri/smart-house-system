#include "registrationwindow.h"
#include <QMessageBox>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QCryptographicHash>
#include <QDebug>
#include <QJsonObject>
#include "networkmanager.h"

RegistrationWindow::RegistrationWindow(QWidget *parent) : QWidget(parent)
{
    QVBoxLayout *layout = new QVBoxLayout(this);

    usernameInput = new QLineEdit(this);
    usernameInput->setPlaceholderText("Введите имя пользователя");

    passwordInput = new QLineEdit(this);
    passwordInput->setPlaceholderText("Введите пароль");
    passwordInput->setEchoMode(QLineEdit::Password);

    confirmPasswordInput = new QLineEdit(this);
    confirmPasswordInput->setPlaceholderText("Подтвердите пароль");
    confirmPasswordInput->setEchoMode(QLineEdit::Password);

    roleComboBox = new QComboBox(this);
    roleComboBox->addItem("admin");
    roleComboBox->addItem("user");

    registerButton = new QPushButton("Зарегистрироваться", this);
    connect(registerButton, &QPushButton::clicked, this, &RegistrationWindow::onRegisterClicked);

    backToLoginButton = new QPushButton("Назад к входу", this);
    connect(backToLoginButton, &QPushButton::clicked, this, [this]() {
        emit goBackToLogin();
        this->close();
    });

    layout->addWidget(usernameInput);
    layout->addWidget(passwordInput);
    layout->addWidget(confirmPasswordInput);
    layout->addWidget(roleComboBox);
    layout->addWidget(registerButton);
    layout->addWidget(backToLoginButton);
}


void RegistrationWindow::onRegisterClicked()
{
    QString username = usernameInput->text();
    QString password = passwordInput->text();
    QString confirmPassword = confirmPasswordInput->text();
    QString role = roleComboBox->currentText();

    if (username.isEmpty() || password.isEmpty()) {
        QMessageBox::warning(this, "Ошибка", "Имя пользователя и пароль не могут быть пустыми!");
        return;
    }

    if (password != confirmPassword) {
        QMessageBox::warning(this, "Ошибка", "Пароли не совпадают!");
        return;
    }
    QByteArray passwordHash = QCryptographicHash::hash(password.toUtf8(), QCryptographicHash::Sha256);
    QString hashedPassword = QString(passwordHash.toHex());
    QJsonObject request;
    request["action"] = "register";
    request["username"] = username;
    request["password"] = hashedPassword;
    request["role"] = role;

    connect(&NetworkManager::instance(), &NetworkManager::responseReceived,
            this, &RegistrationWindow::handleRegistrationResponse);
    NetworkManager::instance().sendRequest(request);
}

void RegistrationWindow::handleRegistrationResponse(const QJsonObject &response) {
    if (response["success"].toBool()) {
        QMessageBox::information(this, "Регистрация", response["message"].toString());
        emit registrationSuccess();
        this->close();
    } else {
        QMessageBox::critical(this, "Ошибка", response["message"].toString());
    }
}


